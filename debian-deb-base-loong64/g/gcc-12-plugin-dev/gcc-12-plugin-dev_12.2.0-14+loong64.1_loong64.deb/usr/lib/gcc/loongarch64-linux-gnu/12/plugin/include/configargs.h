/* Generated automatically. */
static const char configuration_arguments[] = "../src/configure -v --with-pkgversion='Debian 12.2.0-14+loong64.1' --with-bugurl=file:///usr/share/doc/gcc-12/README.Bugs --enable-languages=c,c++,fortran --prefix=/usr --with-gcc-major-version-only --program-suffix=-12 --program-prefix=loongarch64-linux-gnu- --enable-shared --enable-linker-build-id --libexecdir=/usr/lib --without-included-gettext --enable-threads=posix --libdir=/usr/lib --enable-nls --enable-clocale=gnu --enable-libstdcxx-debug --enable-libstdcxx-time=yes --with-default-libstdcxx-abi=new --enable-gnu-unique-object --disable-libitm --disable-libsanitizer --disable-libquadmath --disable-libquadmath-support --enable-plugin --with-system-zlib --enable-multiarch --disable-werror --enable-checking=release --build=loongarch64-linux-gnu --host=loongarch64-linux-gnu --target=loongarch64-linux-gnu";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "lp64d" }, { "arch", "loongarch64" }, { "tune", "la464" }, { "fpu", "64" } };
