/* Generated automatically. */
static const char configuration_arguments[] = "../src/configure -v --with-pkgversion='Debian 13.3.0-8' --with-bugurl=file:///usr/share/doc/gcc-13/README.Bugs --enable-languages=c,c++,fortran,objc,obj-c++ --prefix=/usr --with-gcc-major-version-only --program-suffix=-13 --program-prefix=loongarch64-linux-gnu- --enable-shared --enable-linker-build-id --libexecdir=/usr/libexec --without-included-gettext --enable-threads=posix --libdir=/usr/lib --enable-nls --enable-clocale=gnu --enable-libstdcxx-debug --enable-libstdcxx-time=yes --with-default-libstdcxx-abi=new --enable-libstdcxx-backtrace --enable-gnu-unique-object --disable-libsanitizer --disable-libquadmath --disable-libquadmath-support --enable-plugin --enable-default-pie --with-system-zlib --enable-objc-gc=auto --enable-multiarch --disable-werror --with-abi=lp64d --disable-multilib --enable-checking=release --build=loongarch64-linux-gnu --host=loongarch64-linux-gnu --target=loongarch64-linux-gnu --with-build-config=bootstrap-lto-lean --enable-link-serialization=8";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "lp64d" }, { "arch", "loongarch64" }, { "tune", "la464" }, { "fpu", "64" } };
