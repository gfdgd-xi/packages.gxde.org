/* distro specific configuration injected by the distro build.  */

#ifndef ACCEL_COMPILER
#define DIST_DEFAULT_PKG_METADATA_SPEC 1
#endif
