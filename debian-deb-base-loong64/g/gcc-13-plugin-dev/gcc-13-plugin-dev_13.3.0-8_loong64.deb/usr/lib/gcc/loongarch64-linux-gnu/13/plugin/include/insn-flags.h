/* Generated automatically by the program `genflags'
   from the machine description file `md'.  */

#ifndef GCC_INSN_FLAGS_H
#define GCC_INSN_FLAGS_H

#define HAVE_trap 1
#define HAVE_addsf3 (TARGET_HARD_FLOAT)
#define HAVE_adddf3 (TARGET_DOUBLE_FLOAT)
#define HAVE_addsi3 1
#define HAVE_adddi3 (TARGET_64BIT)
#define HAVE_subsf3 (TARGET_HARD_FLOAT)
#define HAVE_subdf3 (TARGET_DOUBLE_FLOAT)
#define HAVE_subsi3 1
#define HAVE_subdi3 (TARGET_64BIT)
#define HAVE_mulsf3 (TARGET_HARD_FLOAT)
#define HAVE_muldf3 (TARGET_DOUBLE_FLOAT)
#define HAVE_mulsi3 1
#define HAVE_muldi3 (TARGET_64BIT)
#define HAVE_mulsidi3_64bit (TARGET_64BIT)
#define HAVE_muldi3_highpart (TARGET_64BIT)
#define HAVE_umuldi3_highpart (TARGET_64BIT)
#define HAVE_mulsi3_highpart (!TARGET_64BIT)
#define HAVE_umulsi3_highpart (!TARGET_64BIT)
#define HAVE_divdi3_fake 1
#define HAVE_udivdi3_fake 1
#define HAVE_moddi3_fake 1
#define HAVE_umoddi3_fake 1
#define HAVE_fmasf4 (TARGET_HARD_FLOAT)
#define HAVE_fmadf4 (TARGET_DOUBLE_FLOAT)
#define HAVE_fmssf4 (TARGET_HARD_FLOAT)
#define HAVE_fmsdf4 (TARGET_DOUBLE_FLOAT)
#define HAVE_fnmasf4 ((!HONOR_SIGNED_ZEROS (SFmode)) && (TARGET_HARD_FLOAT))
#define HAVE_fnmadf4 ((!HONOR_SIGNED_ZEROS (DFmode)) && (TARGET_DOUBLE_FLOAT))
#define HAVE_fnmssf4 ((!HONOR_SIGNED_ZEROS (SFmode)) && (TARGET_HARD_FLOAT))
#define HAVE_fnmsdf4 ((!HONOR_SIGNED_ZEROS (DFmode)) && (TARGET_DOUBLE_FLOAT))
#define HAVE_sqrtsf2 (TARGET_HARD_FLOAT)
#define HAVE_sqrtdf2 (TARGET_DOUBLE_FLOAT)
#define HAVE_abssf2 (TARGET_HARD_FLOAT)
#define HAVE_absdf2 (TARGET_DOUBLE_FLOAT)
#define HAVE_copysignsf3 (TARGET_HARD_FLOAT)
#define HAVE_copysigndf3 ((TARGET_HARD_FLOAT) && (TARGET_DOUBLE_FLOAT))
#define HAVE_ldexpsf3 (TARGET_HARD_FLOAT)
#define HAVE_ldexpdf3 ((TARGET_HARD_FLOAT) && (TARGET_DOUBLE_FLOAT))
#define HAVE_logb_non_negativesf2 (TARGET_HARD_FLOAT)
#define HAVE_logb_non_negativedf2 ((TARGET_HARD_FLOAT) && (TARGET_DOUBLE_FLOAT))
#define HAVE_clzsi2 1
#define HAVE_clzdi2 (TARGET_64BIT)
#define HAVE_ctzsi2 1
#define HAVE_ctzdi2 (TARGET_64BIT)
#define HAVE_smaxsf3 (TARGET_HARD_FLOAT)
#define HAVE_smaxdf3 (TARGET_DOUBLE_FLOAT)
#define HAVE_sminsf3 (TARGET_HARD_FLOAT)
#define HAVE_smindf3 (TARGET_DOUBLE_FLOAT)
#define HAVE_fmaxsf3 (TARGET_HARD_FLOAT)
#define HAVE_fmaxdf3 (TARGET_DOUBLE_FLOAT)
#define HAVE_fminsf3 (TARGET_HARD_FLOAT)
#define HAVE_fmindf3 (TARGET_DOUBLE_FLOAT)
#define HAVE_smaxasf3 (TARGET_HARD_FLOAT)
#define HAVE_smaxadf3 (TARGET_DOUBLE_FLOAT)
#define HAVE_sminasf3 (TARGET_HARD_FLOAT)
#define HAVE_sminadf3 (TARGET_DOUBLE_FLOAT)
#define HAVE_negsi2 1
#define HAVE_negdi2 (TARGET_64BIT)
#define HAVE_one_cmplsi2 1
#define HAVE_one_cmpldi2 (TARGET_64BIT)
#define HAVE_negsf2 (TARGET_HARD_FLOAT)
#define HAVE_negdf2 (TARGET_DOUBLE_FLOAT)
#define HAVE_andsi3 1
#define HAVE_iorsi3 1
#define HAVE_xorsi3 1
#define HAVE_anddi3 (TARGET_64BIT)
#define HAVE_iordi3 (TARGET_64BIT)
#define HAVE_xordi3 (TARGET_64BIT)
#define HAVE_andsi3_extended 1
#define HAVE_anddi3_extended (TARGET_64BIT)
#define HAVE_andnsi 1
#define HAVE_iornsi 1
#define HAVE_andndi (TARGET_64BIT)
#define HAVE_iorndi (TARGET_64BIT)
#define HAVE_truncdfsf2 (TARGET_DOUBLE_FLOAT)
#define HAVE_zero_extendqisi2 1
#define HAVE_zero_extendqidi2 (TARGET_64BIT)
#define HAVE_zero_extendhisi2 1
#define HAVE_zero_extendhidi2 (TARGET_64BIT)
#define HAVE_zero_extendqihi2 1
#define HAVE_extendsidi2 (TARGET_64BIT)
#define HAVE_extendqisi2 1
#define HAVE_extendqidi2 (TARGET_64BIT)
#define HAVE_extendhisi2 1
#define HAVE_extendhidi2 (TARGET_64BIT)
#define HAVE_extendqihi2 1
#define HAVE_extendsfdf2 (TARGET_DOUBLE_FLOAT)
#define HAVE_fix_truncsfsi2 (TARGET_HARD_FLOAT)
#define HAVE_fix_truncsfdi2 ((TARGET_64BIT) && (TARGET_HARD_FLOAT))
#define HAVE_fix_truncdfsi2 (TARGET_DOUBLE_FLOAT)
#define HAVE_fix_truncdfdi2 ((TARGET_64BIT) && (TARGET_DOUBLE_FLOAT))
#define HAVE_floatsidf2 (TARGET_DOUBLE_FLOAT)
#define HAVE_floatdidf2 (TARGET_DOUBLE_FLOAT)
#define HAVE_floatsisf2 (TARGET_HARD_FLOAT)
#define HAVE_floatdisf2 (TARGET_DOUBLE_FLOAT)
#define HAVE_movfcc 1
#define HAVE_lu32i_d (TARGET_64BIT)
#define HAVE_lu52i_d (TARGET_64BIT)
#define HAVE_tls_lowsi ((TARGET_EXPLICIT_RELOCS) && (Pmode == SImode))
#define HAVE_tls_lowdi ((TARGET_EXPLICIT_RELOCS) && (Pmode == DImode))
#define HAVE_ld_from_gotsi ((TARGET_EXPLICIT_RELOCS) && (Pmode == SImode))
#define HAVE_ld_from_gotdi ((TARGET_EXPLICIT_RELOCS) && (Pmode == DImode))
#define HAVE_lui_l_hi20si (Pmode == SImode)
#define HAVE_lui_l_hi20di (Pmode == DImode)
#define HAVE_pcalau12isi (Pmode == SImode)
#define HAVE_pcalau12idi (Pmode == DImode)
#define HAVE_ori_l_lo12si (Pmode == SImode)
#define HAVE_ori_l_lo12di (Pmode == DImode)
#define HAVE_lui_h_lo20 (TARGET_64BIT)
#define HAVE_lui_h_hi12 (TARGET_64BIT)
#define HAVE_rintsf2 (TARGET_HARD_FLOAT)
#define HAVE_rintdf2 (TARGET_DOUBLE_FLOAT)
#define HAVE_lrintsfsi2 ((TARGET_HARD_FLOAT && \
   (1 \
    || flag_fp_int_builtin_inexact \
    || !flag_trapping_math)) && (TARGET_HARD_FLOAT))
#define HAVE_lfloorsfsi2 ((TARGET_HARD_FLOAT && \
   (0 \
    || flag_fp_int_builtin_inexact \
    || !flag_trapping_math)) && (TARGET_HARD_FLOAT))
#define HAVE_lceilsfsi2 ((TARGET_HARD_FLOAT && \
   (0 \
    || flag_fp_int_builtin_inexact \
    || !flag_trapping_math)) && (TARGET_HARD_FLOAT))
#define HAVE_lrintsfdi2 ((TARGET_HARD_FLOAT && \
   (1 \
    || flag_fp_int_builtin_inexact \
    || !flag_trapping_math)) && ((TARGET_DOUBLE_FLOAT) && (TARGET_HARD_FLOAT)))
#define HAVE_lfloorsfdi2 ((TARGET_HARD_FLOAT && \
   (0 \
    || flag_fp_int_builtin_inexact \
    || !flag_trapping_math)) && ((TARGET_DOUBLE_FLOAT) && (TARGET_HARD_FLOAT)))
#define HAVE_lceilsfdi2 ((TARGET_HARD_FLOAT && \
   (0 \
    || flag_fp_int_builtin_inexact \
    || !flag_trapping_math)) && ((TARGET_DOUBLE_FLOAT) && (TARGET_HARD_FLOAT)))
#define HAVE_lrintdfsi2 ((TARGET_HARD_FLOAT && \
   (1 \
    || flag_fp_int_builtin_inexact \
    || !flag_trapping_math)) && ((TARGET_HARD_FLOAT) && (TARGET_DOUBLE_FLOAT)))
#define HAVE_lfloordfsi2 ((TARGET_HARD_FLOAT && \
   (0 \
    || flag_fp_int_builtin_inexact \
    || !flag_trapping_math)) && ((TARGET_HARD_FLOAT) && (TARGET_DOUBLE_FLOAT)))
#define HAVE_lceildfsi2 ((TARGET_HARD_FLOAT && \
   (0 \
    || flag_fp_int_builtin_inexact \
    || !flag_trapping_math)) && ((TARGET_HARD_FLOAT) && (TARGET_DOUBLE_FLOAT)))
#define HAVE_lrintdfdi2 ((TARGET_HARD_FLOAT && \
   (1 \
    || flag_fp_int_builtin_inexact \
    || !flag_trapping_math)) && (TARGET_DOUBLE_FLOAT))
#define HAVE_lfloordfdi2 ((TARGET_HARD_FLOAT && \
   (0 \
    || flag_fp_int_builtin_inexact \
    || !flag_trapping_math)) && (TARGET_DOUBLE_FLOAT))
#define HAVE_lceildfdi2 ((TARGET_HARD_FLOAT && \
   (0 \
    || flag_fp_int_builtin_inexact \
    || !flag_trapping_math)) && (TARGET_DOUBLE_FLOAT))
#define HAVE_load_lowdf ((TARGET_HARD_FLOAT) && (!TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_load_lowdi ((TARGET_HARD_FLOAT) && (!TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_load_lowtf ((TARGET_HARD_FLOAT) && (TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_load_highdf ((TARGET_HARD_FLOAT) && (!TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_load_highdi ((TARGET_HARD_FLOAT) && (!TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_load_hightf ((TARGET_HARD_FLOAT) && (TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_store_worddf ((TARGET_HARD_FLOAT) && (!TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_store_worddi ((TARGET_HARD_FLOAT) && (!TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_store_wordtf ((TARGET_HARD_FLOAT) && (TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_got_load_tls_gdsi (Pmode == SImode)
#define HAVE_got_load_tls_gddi (Pmode == DImode)
#define HAVE_got_load_tls_ldsi (Pmode == SImode)
#define HAVE_got_load_tls_lddi (Pmode == DImode)
#define HAVE_got_load_tls_lesi (Pmode == SImode)
#define HAVE_got_load_tls_ledi (Pmode == DImode)
#define HAVE_got_load_tls_iesi (Pmode == SImode)
#define HAVE_got_load_tls_iedi (Pmode == DImode)
#define HAVE_movgr2frhdf ((TARGET_DOUBLE_FLOAT) && (!TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_movgr2frhdi ((TARGET_DOUBLE_FLOAT) && (!TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_movgr2frhtf ((TARGET_DOUBLE_FLOAT) && (TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_movfrh2grdf ((TARGET_DOUBLE_FLOAT) && (!TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_movfrh2grdi ((TARGET_DOUBLE_FLOAT) && (!TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_movfrh2grtf ((TARGET_DOUBLE_FLOAT) && (TARGET_64BIT && TARGET_DOUBLE_FLOAT))
#define HAVE_loongarch_ibar 1
#define HAVE_loongarch_dbar 1
#define HAVE_loongarch_cpucfg 1
#define HAVE_loongarch_syscall 1
#define HAVE_loongarch_break 1
#define HAVE_loongarch_asrtle_d (TARGET_64BIT)
#define HAVE_loongarch_asrtgt_d (TARGET_64BIT)
#define HAVE_loongarch_csrrd_w 1
#define HAVE_loongarch_csrrd_d (TARGET_64BIT)
#define HAVE_loongarch_csrwr_w 1
#define HAVE_loongarch_csrwr_d (TARGET_64BIT)
#define HAVE_loongarch_csrxchg_w 1
#define HAVE_loongarch_csrxchg_d (TARGET_64BIT)
#define HAVE_loongarch_iocsrrd_b 1
#define HAVE_loongarch_iocsrrd_h 1
#define HAVE_loongarch_iocsrrd_w 1
#define HAVE_loongarch_iocsrrd_d (TARGET_64BIT)
#define HAVE_loongarch_iocsrwr_b 1
#define HAVE_loongarch_iocsrwr_h 1
#define HAVE_loongarch_iocsrwr_w 1
#define HAVE_loongarch_iocsrwr_d (TARGET_64BIT)
#define HAVE_loongarch_cacop_w (!TARGET_64BIT)
#define HAVE_loongarch_cacop_d (TARGET_64BIT)
#define HAVE_loongarch_lddir_w (!TARGET_64BIT)
#define HAVE_loongarch_lddir_d (TARGET_64BIT)
#define HAVE_loongarch_ldpte_w (!TARGET_64BIT)
#define HAVE_loongarch_ldpte_d (TARGET_64BIT)
#define HAVE_ashlsi3 1
#define HAVE_ashrsi3 1
#define HAVE_lshrsi3 1
#define HAVE_ashldi3 (TARGET_64BIT)
#define HAVE_ashrdi3 (TARGET_64BIT)
#define HAVE_lshrdi3 (TARGET_64BIT)
#define HAVE_rotrsi3 1
#define HAVE_rotrdi3 (TARGET_64BIT)
#define HAVE_zero_extend_ashift (TARGET_64BIT \
   && ((INTVAL (operands[3]) >> INTVAL (operands[2])) == 0xffffffff))
#define HAVE_bstrpick_alsl_paired (TARGET_64BIT \
   && ((INTVAL (operands[4]) >> INTVAL (operands[3])) == 0xffffffff))
#define HAVE_alslsi3 1
#define HAVE_alsldi3 (TARGET_64BIT)
#define HAVE_bswaphi2 1
#define HAVE_bswapsi2 1
#define HAVE_bswapdi2 (TARGET_64BIT)
#define HAVE_revb_2h 1
#define HAVE_revb_4h (TARGET_64BIT)
#define HAVE_revh_d (TARGET_64BIT)
#define HAVE_branch_equalitysi (!TARGET_64BIT)
#define HAVE_branch_equalitydi (TARGET_64BIT)
#define HAVE_sunordered_sf_using_FCCmode (TARGET_HARD_FLOAT)
#define HAVE_suneq_sf_using_FCCmode (TARGET_HARD_FLOAT)
#define HAVE_sunlt_sf_using_FCCmode (TARGET_HARD_FLOAT)
#define HAVE_sunle_sf_using_FCCmode (TARGET_HARD_FLOAT)
#define HAVE_seq_sf_using_FCCmode (TARGET_HARD_FLOAT)
#define HAVE_slt_sf_using_FCCmode (TARGET_HARD_FLOAT)
#define HAVE_sle_sf_using_FCCmode (TARGET_HARD_FLOAT)
#define HAVE_sordered_sf_using_FCCmode (TARGET_HARD_FLOAT)
#define HAVE_sltgt_sf_using_FCCmode (TARGET_HARD_FLOAT)
#define HAVE_sne_sf_using_FCCmode (TARGET_HARD_FLOAT)
#define HAVE_sge_sf_using_FCCmode (TARGET_HARD_FLOAT)
#define HAVE_sgt_sf_using_FCCmode (TARGET_HARD_FLOAT)
#define HAVE_sunge_sf_using_FCCmode (TARGET_HARD_FLOAT)
#define HAVE_sungt_sf_using_FCCmode (TARGET_HARD_FLOAT)
#define HAVE_sunordered_df_using_FCCmode (TARGET_DOUBLE_FLOAT)
#define HAVE_suneq_df_using_FCCmode (TARGET_DOUBLE_FLOAT)
#define HAVE_sunlt_df_using_FCCmode (TARGET_DOUBLE_FLOAT)
#define HAVE_sunle_df_using_FCCmode (TARGET_DOUBLE_FLOAT)
#define HAVE_seq_df_using_FCCmode (TARGET_DOUBLE_FLOAT)
#define HAVE_slt_df_using_FCCmode (TARGET_DOUBLE_FLOAT)
#define HAVE_sle_df_using_FCCmode (TARGET_DOUBLE_FLOAT)
#define HAVE_sordered_df_using_FCCmode (TARGET_DOUBLE_FLOAT)
#define HAVE_sltgt_df_using_FCCmode (TARGET_DOUBLE_FLOAT)
#define HAVE_sne_df_using_FCCmode (TARGET_DOUBLE_FLOAT)
#define HAVE_sge_df_using_FCCmode (TARGET_DOUBLE_FLOAT)
#define HAVE_sgt_df_using_FCCmode (TARGET_DOUBLE_FLOAT)
#define HAVE_sunge_df_using_FCCmode (TARGET_DOUBLE_FLOAT)
#define HAVE_sungt_df_using_FCCmode (TARGET_DOUBLE_FLOAT)
#define HAVE_indirect_jumpsi (Pmode == SImode)
#define HAVE_indirect_jumpdi (Pmode == DImode)
#define HAVE_tablejumpsi (Pmode == SImode)
#define HAVE_tablejumpdi (Pmode == DImode)
#define HAVE_blockage 1
#define HAVE_probe_stack_rangesi (Pmode == SImode)
#define HAVE_probe_stack_rangedi (Pmode == DImode)
#define HAVE_return_internal 1
#define HAVE_simple_return_internal 1
#define HAVE_loongarch_ertn 1
#define HAVE_eh_return_internal 1
#define HAVE_eh_set_ra_si (! TARGET_64BIT)
#define HAVE_eh_set_ra_di (TARGET_64BIT)
#define HAVE_sibcall_internal (SIBLING_CALL_P (insn))
#define HAVE_sibcall_internal_1si ((SIBLING_CALL_P (insn) && TARGET_CMODEL_MEDIUM) && (Pmode == SImode))
#define HAVE_sibcall_internal_1di ((SIBLING_CALL_P (insn) && TARGET_CMODEL_MEDIUM) && (Pmode == DImode))
#define HAVE_sibcall_value_internal (SIBLING_CALL_P (insn))
#define HAVE_sibcall_value_internal_1si ((SIBLING_CALL_P (insn) && TARGET_CMODEL_MEDIUM) && (Pmode == SImode))
#define HAVE_sibcall_value_internal_1di ((SIBLING_CALL_P (insn) && TARGET_CMODEL_MEDIUM) && (Pmode == DImode))
#define HAVE_sibcall_value_multiple_internal (SIBLING_CALL_P (insn))
#define HAVE_sibcall_value_multiple_internal_1si ((SIBLING_CALL_P (insn) && TARGET_CMODEL_MEDIUM) && (Pmode == SImode))
#define HAVE_sibcall_value_multiple_internal_1di ((SIBLING_CALL_P (insn) && TARGET_CMODEL_MEDIUM) && (Pmode == DImode))
#define HAVE_call_internal 1
#define HAVE_call_internal_1si ((TARGET_CMODEL_MEDIUM) && (Pmode == SImode))
#define HAVE_call_internal_1di ((TARGET_CMODEL_MEDIUM) && (Pmode == DImode))
#define HAVE_call_value_internal 1
#define HAVE_call_value_internal_1si ((TARGET_CMODEL_MEDIUM) && (Pmode == SImode))
#define HAVE_call_value_internal_1di ((TARGET_CMODEL_MEDIUM) && (Pmode == DImode))
#define HAVE_call_value_multiple_internal 1
#define HAVE_call_value_multiple_internal_1si ((TARGET_CMODEL_MEDIUM) && (Pmode == SImode))
#define HAVE_call_value_multiple_internal_1di ((TARGET_CMODEL_MEDIUM) && (Pmode == DImode))
#define HAVE_prefetch 1
#define HAVE_nop 1
#define HAVE_loongarch_movfcsr2gr (TARGET_HARD_FLOAT)
#define HAVE_loongarch_movgr2fcsr (TARGET_HARD_FLOAT)
#define HAVE_fclass_s (TARGET_HARD_FLOAT)
#define HAVE_fclass_d ((TARGET_HARD_FLOAT) && (TARGET_DOUBLE_FLOAT))
#define HAVE_bytepick_w_1 1
#define HAVE_bytepick_w_2 1
#define HAVE_bytepick_w_3 1
#define HAVE_bytepick_w_1_extend (TARGET_64BIT)
#define HAVE_bytepick_w_2_extend (TARGET_64BIT)
#define HAVE_bytepick_w_3_extend (TARGET_64BIT)
#define HAVE_bytepick_d_1 (TARGET_64BIT)
#define HAVE_bytepick_d_2 (TARGET_64BIT)
#define HAVE_bytepick_d_3 (TARGET_64BIT)
#define HAVE_bytepick_d_4 (TARGET_64BIT)
#define HAVE_bytepick_d_5 (TARGET_64BIT)
#define HAVE_bytepick_d_6 (TARGET_64BIT)
#define HAVE_bytepick_d_7 (TARGET_64BIT)
#define HAVE_bitrev_4b 1
#define HAVE_bitrev_8b 1
#define HAVE_stack_tiesi (!TARGET_64BIT)
#define HAVE_stack_tiedi (TARGET_64BIT)
#define HAVE_loongarch_crc_w_b_w 1
#define HAVE_loongarch_crc_w_h_w 1
#define HAVE_loongarch_crc_w_w_w 1
#define HAVE_loongarch_crc_w_d_w 1
#define HAVE_loongarch_crcc_w_b_w 1
#define HAVE_loongarch_crcc_w_h_w 1
#define HAVE_loongarch_crcc_w_w_w 1
#define HAVE_loongarch_crcc_w_d_w 1
#define HAVE_mem_thread_fence_1 1
#define HAVE_atomic_storesi 1
#define HAVE_atomic_storedi (TARGET_64BIT)
#define HAVE_atomic_addsi 1
#define HAVE_atomic_orsi 1
#define HAVE_atomic_xorsi 1
#define HAVE_atomic_andsi 1
#define HAVE_atomic_adddi (TARGET_64BIT)
#define HAVE_atomic_ordi (TARGET_64BIT)
#define HAVE_atomic_xordi (TARGET_64BIT)
#define HAVE_atomic_anddi (TARGET_64BIT)
#define HAVE_atomic_fetch_addsi 1
#define HAVE_atomic_fetch_orsi 1
#define HAVE_atomic_fetch_xorsi 1
#define HAVE_atomic_fetch_andsi 1
#define HAVE_atomic_fetch_adddi (TARGET_64BIT)
#define HAVE_atomic_fetch_ordi (TARGET_64BIT)
#define HAVE_atomic_fetch_xordi (TARGET_64BIT)
#define HAVE_atomic_fetch_anddi (TARGET_64BIT)
#define HAVE_atomic_exchangesi 1
#define HAVE_atomic_exchangedi (TARGET_64BIT)
#define HAVE_atomic_cas_value_strongsi 1
#define HAVE_atomic_cas_value_strongdi (TARGET_64BIT)
#define HAVE_atomic_cas_value_cmp_and_7_si 1
#define HAVE_atomic_cas_value_cmp_and_7_di (TARGET_64BIT)
#define HAVE_atomic_cas_value_add_7_si 1
#define HAVE_atomic_cas_value_add_7_di (TARGET_64BIT)
#define HAVE_atomic_cas_value_sub_7_si 1
#define HAVE_atomic_cas_value_sub_7_di (TARGET_64BIT)
#define HAVE_atomic_cas_value_and_7_si 1
#define HAVE_atomic_cas_value_and_7_di (TARGET_64BIT)
#define HAVE_atomic_cas_value_xor_7_si 1
#define HAVE_atomic_cas_value_xor_7_di (TARGET_64BIT)
#define HAVE_atomic_cas_value_or_7_si 1
#define HAVE_atomic_cas_value_or_7_di (TARGET_64BIT)
#define HAVE_atomic_cas_value_nand_7_si 1
#define HAVE_atomic_cas_value_nand_7_di (TARGET_64BIT)
#define HAVE_atomic_cas_value_exchange_7_si 1
#define HAVE_atomic_cas_value_exchange_7_di (TARGET_64BIT)
#define HAVE_mulditi3 (TARGET_64BIT)
#define HAVE_umulditi3 (TARGET_64BIT)
#define HAVE_mulsidi3 (!TARGET_64BIT)
#define HAVE_umulsidi3 (!TARGET_64BIT)
#define HAVE_divsf3 (TARGET_HARD_FLOAT)
#define HAVE_divdf3 (TARGET_DOUBLE_FLOAT)
#define HAVE_divsi3 1
#define HAVE_udivsi3 1
#define HAVE_modsi3 1
#define HAVE_umodsi3 1
#define HAVE_divdi3 (TARGET_64BIT)
#define HAVE_udivdi3 (TARGET_64BIT)
#define HAVE_moddi3 (TARGET_64BIT)
#define HAVE_umoddi3 (TARGET_64BIT)
#define HAVE_logbsf2 (TARGET_HARD_FLOAT)
#define HAVE_logbdf2 ((TARGET_HARD_FLOAT) && (TARGET_DOUBLE_FLOAT))
#define HAVE_zero_extendsidi2 (TARGET_64BIT)
#define HAVE_fixuns_truncdfsi2 (TARGET_DOUBLE_FLOAT)
#define HAVE_fixuns_truncdfdi2 (TARGET_DOUBLE_FLOAT)
#define HAVE_fixuns_truncsfsi2 (TARGET_HARD_FLOAT)
#define HAVE_fixuns_truncsfdi2 (TARGET_DOUBLE_FLOAT)
#define HAVE_extzvsi (!TARGET_64BIT)
#define HAVE_extzvdi (TARGET_64BIT)
#define HAVE_insvsi 1
#define HAVE_insvdi (TARGET_64BIT)
#define HAVE_movdi 1
#define HAVE_movsi 1
#define HAVE_movhi 1
#define HAVE_movqi 1
#define HAVE_movsf 1
#define HAVE_movdf 1
#define HAVE_move_doubleword_fprdf (!TARGET_64BIT && TARGET_DOUBLE_FLOAT)
#define HAVE_move_doubleword_fprdi (!TARGET_64BIT && TARGET_DOUBLE_FLOAT)
#define HAVE_move_doubleword_fprtf (TARGET_64BIT && TARGET_DOUBLE_FLOAT)
#define HAVE_movsicc (TARGET_COND_MOVE_INT)
#define HAVE_movdicc ((TARGET_COND_MOVE_INT) && (TARGET_64BIT))
#define HAVE_movsfcc ((TARGET_COND_MOVE_FLOAT) && (TARGET_HARD_FLOAT))
#define HAVE_movdfcc ((TARGET_COND_MOVE_FLOAT) && (TARGET_DOUBLE_FLOAT))
#define HAVE_clear_cache 1
#define HAVE_cpymemsi 1
#define HAVE_cbranchsi4 1
#define HAVE_cbranchdi4 (TARGET_64BIT)
#define HAVE_cbranchsf4 (TARGET_HARD_FLOAT)
#define HAVE_cbranchdf4 (TARGET_DOUBLE_FLOAT)
#define HAVE_condjump 1
#define HAVE_cstoresi4 1
#define HAVE_cstoredi4 (TARGET_64BIT)
#define HAVE_jump 1
#define HAVE_indirect_jump 1
#define HAVE_tablejump 1
#define HAVE_prologue 1
#define HAVE_epilogue 1
#define HAVE_sibcall_epilogue 1
#define HAVE_return (loongarch_can_use_return_insn ())
#define HAVE_simple_return 1
#define HAVE_eh_return 1
#define HAVE_sibcall 1
#define HAVE_sibcall_value 1
#define HAVE_call 1
#define HAVE_call_value 1
#define HAVE_untyped_call 1
#define HAVE_get_thread_pointersi ((HAVE_AS_TLS) && (Pmode == SImode))
#define HAVE_get_thread_pointerdi ((HAVE_AS_TLS) && (Pmode == DImode))
#define HAVE_mem_thread_fence 1
#define HAVE_atomic_compare_and_swapsi 1
#define HAVE_atomic_compare_and_swapdi (TARGET_64BIT)
#define HAVE_atomic_test_and_set 1
#define HAVE_atomic_compare_and_swapqi 1
#define HAVE_atomic_compare_and_swaphi 1
#define HAVE_atomic_exchangeqi 1
#define HAVE_atomic_exchangehi 1
#define HAVE_atomic_fetch_addqi 1
#define HAVE_atomic_fetch_addhi 1
#define HAVE_atomic_fetch_subqi 1
#define HAVE_atomic_fetch_subhi 1
#define HAVE_atomic_fetch_andqi 1
#define HAVE_atomic_fetch_andhi 1
#define HAVE_atomic_fetch_xorqi 1
#define HAVE_atomic_fetch_xorhi 1
#define HAVE_atomic_fetch_orqi 1
#define HAVE_atomic_fetch_orhi 1
#define HAVE_atomic_fetch_nandqi 1
#define HAVE_atomic_fetch_nandhi 1
extern rtx        gen_trap                                (void);
extern rtx        gen_addsf3                              (rtx, rtx, rtx);
extern rtx        gen_adddf3                              (rtx, rtx, rtx);
extern rtx        gen_addsi3                              (rtx, rtx, rtx);
extern rtx        gen_adddi3                              (rtx, rtx, rtx);
extern rtx        gen_subsf3                              (rtx, rtx, rtx);
extern rtx        gen_subdf3                              (rtx, rtx, rtx);
extern rtx        gen_subsi3                              (rtx, rtx, rtx);
extern rtx        gen_subdi3                              (rtx, rtx, rtx);
extern rtx        gen_mulsf3                              (rtx, rtx, rtx);
extern rtx        gen_muldf3                              (rtx, rtx, rtx);
extern rtx        gen_mulsi3                              (rtx, rtx, rtx);
extern rtx        gen_muldi3                              (rtx, rtx, rtx);
extern rtx        gen_mulsidi3_64bit                      (rtx, rtx, rtx);
extern rtx        gen_muldi3_highpart                     (rtx, rtx, rtx);
extern rtx        gen_umuldi3_highpart                    (rtx, rtx, rtx);
extern rtx        gen_mulsi3_highpart                     (rtx, rtx, rtx);
extern rtx        gen_umulsi3_highpart                    (rtx, rtx, rtx);
extern rtx        gen_divdi3_fake                         (rtx, rtx, rtx);
extern rtx        gen_udivdi3_fake                        (rtx, rtx, rtx);
extern rtx        gen_moddi3_fake                         (rtx, rtx, rtx);
extern rtx        gen_umoddi3_fake                        (rtx, rtx, rtx);
extern rtx        gen_fmasf4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_fmadf4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_fmssf4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_fmsdf4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmasf4                             (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmadf4                             (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmssf4                             (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmsdf4                             (rtx, rtx, rtx, rtx);
extern rtx        gen_sqrtsf2                             (rtx, rtx);
extern rtx        gen_sqrtdf2                             (rtx, rtx);
extern rtx        gen_abssf2                              (rtx, rtx);
extern rtx        gen_absdf2                              (rtx, rtx);
extern rtx        gen_copysignsf3                         (rtx, rtx, rtx);
extern rtx        gen_copysigndf3                         (rtx, rtx, rtx);
extern rtx        gen_ldexpsf3                            (rtx, rtx, rtx);
extern rtx        gen_ldexpdf3                            (rtx, rtx, rtx);
extern rtx        gen_logb_non_negativesf2                (rtx, rtx);
extern rtx        gen_logb_non_negativedf2                (rtx, rtx);
extern rtx        gen_clzsi2                              (rtx, rtx);
extern rtx        gen_clzdi2                              (rtx, rtx);
extern rtx        gen_ctzsi2                              (rtx, rtx);
extern rtx        gen_ctzdi2                              (rtx, rtx);
extern rtx        gen_smaxsf3                             (rtx, rtx, rtx);
extern rtx        gen_smaxdf3                             (rtx, rtx, rtx);
extern rtx        gen_sminsf3                             (rtx, rtx, rtx);
extern rtx        gen_smindf3                             (rtx, rtx, rtx);
extern rtx        gen_fmaxsf3                             (rtx, rtx, rtx);
extern rtx        gen_fmaxdf3                             (rtx, rtx, rtx);
extern rtx        gen_fminsf3                             (rtx, rtx, rtx);
extern rtx        gen_fmindf3                             (rtx, rtx, rtx);
extern rtx        gen_smaxasf3                            (rtx, rtx, rtx);
extern rtx        gen_smaxadf3                            (rtx, rtx, rtx);
extern rtx        gen_sminasf3                            (rtx, rtx, rtx);
extern rtx        gen_sminadf3                            (rtx, rtx, rtx);
extern rtx        gen_negsi2                              (rtx, rtx);
extern rtx        gen_negdi2                              (rtx, rtx);
extern rtx        gen_one_cmplsi2                         (rtx, rtx);
extern rtx        gen_one_cmpldi2                         (rtx, rtx);
extern rtx        gen_negsf2                              (rtx, rtx);
extern rtx        gen_negdf2                              (rtx, rtx);
extern rtx        gen_andsi3                              (rtx, rtx, rtx);
extern rtx        gen_iorsi3                              (rtx, rtx, rtx);
extern rtx        gen_xorsi3                              (rtx, rtx, rtx);
extern rtx        gen_anddi3                              (rtx, rtx, rtx);
extern rtx        gen_iordi3                              (rtx, rtx, rtx);
extern rtx        gen_xordi3                              (rtx, rtx, rtx);
extern rtx        gen_andsi3_extended                     (rtx, rtx, rtx);
extern rtx        gen_anddi3_extended                     (rtx, rtx, rtx);
extern rtx        gen_andnsi                              (rtx, rtx, rtx);
extern rtx        gen_iornsi                              (rtx, rtx, rtx);
extern rtx        gen_andndi                              (rtx, rtx, rtx);
extern rtx        gen_iorndi                              (rtx, rtx, rtx);
extern rtx        gen_truncdfsf2                          (rtx, rtx);
extern rtx        gen_zero_extendqisi2                    (rtx, rtx);
extern rtx        gen_zero_extendqidi2                    (rtx, rtx);
extern rtx        gen_zero_extendhisi2                    (rtx, rtx);
extern rtx        gen_zero_extendhidi2                    (rtx, rtx);
extern rtx        gen_zero_extendqihi2                    (rtx, rtx);
extern rtx        gen_extendsidi2                         (rtx, rtx);
extern rtx        gen_extendqisi2                         (rtx, rtx);
extern rtx        gen_extendqidi2                         (rtx, rtx);
extern rtx        gen_extendhisi2                         (rtx, rtx);
extern rtx        gen_extendhidi2                         (rtx, rtx);
extern rtx        gen_extendqihi2                         (rtx, rtx);
extern rtx        gen_extendsfdf2                         (rtx, rtx);
extern rtx        gen_fix_truncsfsi2                      (rtx, rtx);
extern rtx        gen_fix_truncsfdi2                      (rtx, rtx);
extern rtx        gen_fix_truncdfsi2                      (rtx, rtx);
extern rtx        gen_fix_truncdfdi2                      (rtx, rtx);
extern rtx        gen_floatsidf2                          (rtx, rtx);
extern rtx        gen_floatdidf2                          (rtx, rtx);
extern rtx        gen_floatsisf2                          (rtx, rtx);
extern rtx        gen_floatdisf2                          (rtx, rtx);
extern rtx        gen_movfcc                              (rtx);
extern rtx        gen_lu32i_d                             (rtx, rtx, rtx);
extern rtx        gen_lu52i_d                             (rtx, rtx, rtx, rtx);
extern rtx        gen_tls_lowsi                           (rtx, rtx, rtx);
extern rtx        gen_tls_lowdi                           (rtx, rtx, rtx);
extern rtx        gen_ld_from_gotsi                       (rtx, rtx, rtx);
extern rtx        gen_ld_from_gotdi                       (rtx, rtx, rtx);
extern rtx        gen_lui_l_hi20si                        (rtx, rtx);
extern rtx        gen_lui_l_hi20di                        (rtx, rtx);
extern rtx        gen_pcalau12isi                         (rtx, rtx);
extern rtx        gen_pcalau12idi                         (rtx, rtx);
extern rtx        gen_ori_l_lo12si                        (rtx, rtx, rtx);
extern rtx        gen_ori_l_lo12di                        (rtx, rtx, rtx);
extern rtx        gen_lui_h_lo20                          (rtx, rtx, rtx);
extern rtx        gen_lui_h_hi12                          (rtx, rtx, rtx);
extern rtx        gen_rintsf2                             (rtx, rtx);
extern rtx        gen_rintdf2                             (rtx, rtx);
extern rtx        gen_lrintsfsi2                          (rtx, rtx);
extern rtx        gen_lfloorsfsi2                         (rtx, rtx);
extern rtx        gen_lceilsfsi2                          (rtx, rtx);
extern rtx        gen_lrintsfdi2                          (rtx, rtx);
extern rtx        gen_lfloorsfdi2                         (rtx, rtx);
extern rtx        gen_lceilsfdi2                          (rtx, rtx);
extern rtx        gen_lrintdfsi2                          (rtx, rtx);
extern rtx        gen_lfloordfsi2                         (rtx, rtx);
extern rtx        gen_lceildfsi2                          (rtx, rtx);
extern rtx        gen_lrintdfdi2                          (rtx, rtx);
extern rtx        gen_lfloordfdi2                         (rtx, rtx);
extern rtx        gen_lceildfdi2                          (rtx, rtx);
extern rtx        gen_load_lowdf                          (rtx, rtx);
extern rtx        gen_load_lowdi                          (rtx, rtx);
extern rtx        gen_load_lowtf                          (rtx, rtx);
extern rtx        gen_load_highdf                         (rtx, rtx, rtx);
extern rtx        gen_load_highdi                         (rtx, rtx, rtx);
extern rtx        gen_load_hightf                         (rtx, rtx, rtx);
extern rtx        gen_store_worddf                        (rtx, rtx, rtx);
extern rtx        gen_store_worddi                        (rtx, rtx, rtx);
extern rtx        gen_store_wordtf                        (rtx, rtx, rtx);
extern rtx        gen_got_load_tls_gdsi                   (rtx, rtx);
extern rtx        gen_got_load_tls_gddi                   (rtx, rtx);
extern rtx        gen_got_load_tls_ldsi                   (rtx, rtx);
extern rtx        gen_got_load_tls_lddi                   (rtx, rtx);
extern rtx        gen_got_load_tls_lesi                   (rtx, rtx);
extern rtx        gen_got_load_tls_ledi                   (rtx, rtx);
extern rtx        gen_got_load_tls_iesi                   (rtx, rtx);
extern rtx        gen_got_load_tls_iedi                   (rtx, rtx);
extern rtx        gen_movgr2frhdf                         (rtx, rtx, rtx);
extern rtx        gen_movgr2frhdi                         (rtx, rtx, rtx);
extern rtx        gen_movgr2frhtf                         (rtx, rtx, rtx);
extern rtx        gen_movfrh2grdf                         (rtx, rtx);
extern rtx        gen_movfrh2grdi                         (rtx, rtx);
extern rtx        gen_movfrh2grtf                         (rtx, rtx);
extern rtx        gen_loongarch_ibar                      (rtx);
extern rtx        gen_loongarch_dbar                      (rtx);
extern rtx        gen_loongarch_cpucfg                    (rtx, rtx);
extern rtx        gen_loongarch_syscall                   (rtx);
extern rtx        gen_loongarch_break                     (rtx);
extern rtx        gen_loongarch_asrtle_d                  (rtx, rtx);
extern rtx        gen_loongarch_asrtgt_d                  (rtx, rtx);
extern rtx        gen_loongarch_csrrd_w                   (rtx, rtx);
extern rtx        gen_loongarch_csrrd_d                   (rtx, rtx);
extern rtx        gen_loongarch_csrwr_w                   (rtx, rtx, rtx);
extern rtx        gen_loongarch_csrwr_d                   (rtx, rtx, rtx);
extern rtx        gen_loongarch_csrxchg_w                 (rtx, rtx, rtx, rtx);
extern rtx        gen_loongarch_csrxchg_d                 (rtx, rtx, rtx, rtx);
extern rtx        gen_loongarch_iocsrrd_b                 (rtx, rtx);
extern rtx        gen_loongarch_iocsrrd_h                 (rtx, rtx);
extern rtx        gen_loongarch_iocsrrd_w                 (rtx, rtx);
extern rtx        gen_loongarch_iocsrrd_d                 (rtx, rtx);
extern rtx        gen_loongarch_iocsrwr_b                 (rtx, rtx);
extern rtx        gen_loongarch_iocsrwr_h                 (rtx, rtx);
extern rtx        gen_loongarch_iocsrwr_w                 (rtx, rtx);
extern rtx        gen_loongarch_iocsrwr_d                 (rtx, rtx);
extern rtx        gen_loongarch_cacop_w                   (rtx, rtx, rtx);
extern rtx        gen_loongarch_cacop_d                   (rtx, rtx, rtx);
extern rtx        gen_loongarch_lddir_w                   (rtx, rtx, rtx);
extern rtx        gen_loongarch_lddir_d                   (rtx, rtx, rtx);
extern rtx        gen_loongarch_ldpte_w                   (rtx, rtx);
extern rtx        gen_loongarch_ldpte_d                   (rtx, rtx);
extern rtx        gen_ashlsi3                             (rtx, rtx, rtx);
extern rtx        gen_ashrsi3                             (rtx, rtx, rtx);
extern rtx        gen_lshrsi3                             (rtx, rtx, rtx);
extern rtx        gen_ashldi3                             (rtx, rtx, rtx);
extern rtx        gen_ashrdi3                             (rtx, rtx, rtx);
extern rtx        gen_lshrdi3                             (rtx, rtx, rtx);
extern rtx        gen_rotrsi3                             (rtx, rtx, rtx);
extern rtx        gen_rotrdi3                             (rtx, rtx, rtx);
extern rtx        gen_zero_extend_ashift                  (rtx, rtx, rtx, rtx);
extern rtx        gen_bstrpick_alsl_paired                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_alslsi3                             (rtx, rtx, rtx, rtx);
extern rtx        gen_alsldi3                             (rtx, rtx, rtx, rtx);
extern rtx        gen_bswaphi2                            (rtx, rtx);
extern rtx        gen_bswapsi2                            (rtx, rtx);
extern rtx        gen_bswapdi2                            (rtx, rtx);
extern rtx        gen_revb_2h                             (rtx, rtx);
extern rtx        gen_revb_4h                             (rtx, rtx);
extern rtx        gen_revh_d                              (rtx, rtx);
extern rtx        gen_branch_equalitysi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_branch_equalitydi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_sunordered_sf_using_FCCmode         (rtx, rtx, rtx);
extern rtx        gen_suneq_sf_using_FCCmode              (rtx, rtx, rtx);
extern rtx        gen_sunlt_sf_using_FCCmode              (rtx, rtx, rtx);
extern rtx        gen_sunle_sf_using_FCCmode              (rtx, rtx, rtx);
extern rtx        gen_seq_sf_using_FCCmode                (rtx, rtx, rtx);
extern rtx        gen_slt_sf_using_FCCmode                (rtx, rtx, rtx);
extern rtx        gen_sle_sf_using_FCCmode                (rtx, rtx, rtx);
extern rtx        gen_sordered_sf_using_FCCmode           (rtx, rtx, rtx);
extern rtx        gen_sltgt_sf_using_FCCmode              (rtx, rtx, rtx);
extern rtx        gen_sne_sf_using_FCCmode                (rtx, rtx, rtx);
extern rtx        gen_sge_sf_using_FCCmode                (rtx, rtx, rtx);
extern rtx        gen_sgt_sf_using_FCCmode                (rtx, rtx, rtx);
extern rtx        gen_sunge_sf_using_FCCmode              (rtx, rtx, rtx);
extern rtx        gen_sungt_sf_using_FCCmode              (rtx, rtx, rtx);
extern rtx        gen_sunordered_df_using_FCCmode         (rtx, rtx, rtx);
extern rtx        gen_suneq_df_using_FCCmode              (rtx, rtx, rtx);
extern rtx        gen_sunlt_df_using_FCCmode              (rtx, rtx, rtx);
extern rtx        gen_sunle_df_using_FCCmode              (rtx, rtx, rtx);
extern rtx        gen_seq_df_using_FCCmode                (rtx, rtx, rtx);
extern rtx        gen_slt_df_using_FCCmode                (rtx, rtx, rtx);
extern rtx        gen_sle_df_using_FCCmode                (rtx, rtx, rtx);
extern rtx        gen_sordered_df_using_FCCmode           (rtx, rtx, rtx);
extern rtx        gen_sltgt_df_using_FCCmode              (rtx, rtx, rtx);
extern rtx        gen_sne_df_using_FCCmode                (rtx, rtx, rtx);
extern rtx        gen_sge_df_using_FCCmode                (rtx, rtx, rtx);
extern rtx        gen_sgt_df_using_FCCmode                (rtx, rtx, rtx);
extern rtx        gen_sunge_df_using_FCCmode              (rtx, rtx, rtx);
extern rtx        gen_sungt_df_using_FCCmode              (rtx, rtx, rtx);
extern rtx        gen_indirect_jumpsi                     (rtx);
extern rtx        gen_indirect_jumpdi                     (rtx);
extern rtx        gen_tablejumpsi                         (rtx, rtx);
extern rtx        gen_tablejumpdi                         (rtx, rtx);
extern rtx        gen_blockage                            (void);
extern rtx        gen_probe_stack_rangesi                 (rtx, rtx, rtx, rtx);
extern rtx        gen_probe_stack_rangedi                 (rtx, rtx, rtx, rtx);
extern rtx        gen_return_internal                     (rtx);
extern rtx        gen_simple_return_internal              (rtx);
extern rtx        gen_loongarch_ertn                      (void);
extern rtx        gen_eh_return_internal                  (void);
extern rtx        gen_eh_set_ra_si                        (rtx);
extern rtx        gen_eh_set_ra_di                        (rtx);
extern rtx        gen_sibcall_internal                    (rtx, rtx);
extern rtx        gen_sibcall_internal_1si                (rtx, rtx, rtx);
extern rtx        gen_sibcall_internal_1di                (rtx, rtx, rtx);
extern rtx        gen_sibcall_value_internal              (rtx, rtx, rtx);
extern rtx        gen_sibcall_value_internal_1si          (rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall_value_internal_1di          (rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall_value_multiple_internal     (rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall_value_multiple_internal_1si (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall_value_multiple_internal_1di (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_call_internal                       (rtx, rtx);
extern rtx        gen_call_internal_1si                   (rtx, rtx, rtx);
extern rtx        gen_call_internal_1di                   (rtx, rtx, rtx);
extern rtx        gen_call_value_internal                 (rtx, rtx, rtx);
extern rtx        gen_call_value_internal_1si             (rtx, rtx, rtx, rtx);
extern rtx        gen_call_value_internal_1di             (rtx, rtx, rtx, rtx);
extern rtx        gen_call_value_multiple_internal        (rtx, rtx, rtx, rtx);
extern rtx        gen_call_value_multiple_internal_1si    (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_call_value_multiple_internal_1di    (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_prefetch                            (rtx, rtx, rtx);
extern rtx        gen_nop                                 (void);
extern rtx        gen_loongarch_movfcsr2gr                (rtx, rtx);
extern rtx        gen_loongarch_movgr2fcsr                (rtx, rtx);
extern rtx        gen_fclass_s                            (rtx, rtx);
extern rtx        gen_fclass_d                            (rtx, rtx);
extern rtx        gen_bytepick_w_1                        (rtx, rtx, rtx);
extern rtx        gen_bytepick_w_2                        (rtx, rtx, rtx);
extern rtx        gen_bytepick_w_3                        (rtx, rtx, rtx);
extern rtx        gen_bytepick_w_1_extend                 (rtx, rtx, rtx);
extern rtx        gen_bytepick_w_2_extend                 (rtx, rtx, rtx);
extern rtx        gen_bytepick_w_3_extend                 (rtx, rtx, rtx);
extern rtx        gen_bytepick_d_1                        (rtx, rtx, rtx);
extern rtx        gen_bytepick_d_2                        (rtx, rtx, rtx);
extern rtx        gen_bytepick_d_3                        (rtx, rtx, rtx);
extern rtx        gen_bytepick_d_4                        (rtx, rtx, rtx);
extern rtx        gen_bytepick_d_5                        (rtx, rtx, rtx);
extern rtx        gen_bytepick_d_6                        (rtx, rtx, rtx);
extern rtx        gen_bytepick_d_7                        (rtx, rtx, rtx);
extern rtx        gen_bitrev_4b                           (rtx, rtx);
extern rtx        gen_bitrev_8b                           (rtx, rtx);
extern rtx        gen_stack_tiesi                         (rtx, rtx);
extern rtx        gen_stack_tiedi                         (rtx, rtx);
extern rtx        gen_loongarch_crc_w_b_w                 (rtx, rtx, rtx);
extern rtx        gen_loongarch_crc_w_h_w                 (rtx, rtx, rtx);
extern rtx        gen_loongarch_crc_w_w_w                 (rtx, rtx, rtx);
extern rtx        gen_loongarch_crc_w_d_w                 (rtx, rtx, rtx);
extern rtx        gen_loongarch_crcc_w_b_w                (rtx, rtx, rtx);
extern rtx        gen_loongarch_crcc_w_h_w                (rtx, rtx, rtx);
extern rtx        gen_loongarch_crcc_w_w_w                (rtx, rtx, rtx);
extern rtx        gen_loongarch_crcc_w_d_w                (rtx, rtx, rtx);
extern rtx        gen_mem_thread_fence_1                  (rtx, rtx);
extern rtx        gen_atomic_storesi                      (rtx, rtx, rtx);
extern rtx        gen_atomic_storedi                      (rtx, rtx, rtx);
extern rtx        gen_atomic_addsi                        (rtx, rtx, rtx);
extern rtx        gen_atomic_orsi                         (rtx, rtx, rtx);
extern rtx        gen_atomic_xorsi                        (rtx, rtx, rtx);
extern rtx        gen_atomic_andsi                        (rtx, rtx, rtx);
extern rtx        gen_atomic_adddi                        (rtx, rtx, rtx);
extern rtx        gen_atomic_ordi                         (rtx, rtx, rtx);
extern rtx        gen_atomic_xordi                        (rtx, rtx, rtx);
extern rtx        gen_atomic_anddi                        (rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_addsi                  (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_orsi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xorsi                  (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_andsi                  (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_adddi                  (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_ordi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xordi                  (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_anddi                  (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangesi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangedi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_strongsi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_strongdi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_cmp_and_7_si       (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_cmp_and_7_di       (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_add_7_si           (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_add_7_di           (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_sub_7_si           (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_sub_7_di           (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_and_7_si           (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_and_7_di           (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_xor_7_si           (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_xor_7_di           (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_or_7_si            (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_or_7_di            (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_nand_7_si          (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_nand_7_di          (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_exchange_7_si      (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_cas_value_exchange_7_di      (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_mulditi3                            (rtx, rtx, rtx);
extern rtx        gen_umulditi3                           (rtx, rtx, rtx);
extern rtx        gen_mulsidi3                            (rtx, rtx, rtx);
extern rtx        gen_umulsidi3                           (rtx, rtx, rtx);
extern rtx        gen_divsf3                              (rtx, rtx, rtx);
extern rtx        gen_divdf3                              (rtx, rtx, rtx);
extern rtx        gen_divsi3                              (rtx, rtx, rtx);
extern rtx        gen_udivsi3                             (rtx, rtx, rtx);
extern rtx        gen_modsi3                              (rtx, rtx, rtx);
extern rtx        gen_umodsi3                             (rtx, rtx, rtx);
extern rtx        gen_divdi3                              (rtx, rtx, rtx);
extern rtx        gen_udivdi3                             (rtx, rtx, rtx);
extern rtx        gen_moddi3                              (rtx, rtx, rtx);
extern rtx        gen_umoddi3                             (rtx, rtx, rtx);
extern rtx        gen_logbsf2                             (rtx, rtx);
extern rtx        gen_logbdf2                             (rtx, rtx);
extern rtx        gen_zero_extendsidi2                    (rtx, rtx);
extern rtx        gen_fixuns_truncdfsi2                   (rtx, rtx);
extern rtx        gen_fixuns_truncdfdi2                   (rtx, rtx);
extern rtx        gen_fixuns_truncsfsi2                   (rtx, rtx);
extern rtx        gen_fixuns_truncsfdi2                   (rtx, rtx);
extern rtx        gen_extzvsi                             (rtx, rtx, rtx, rtx);
extern rtx        gen_extzvdi                             (rtx, rtx, rtx, rtx);
extern rtx        gen_insvsi                              (rtx, rtx, rtx, rtx);
extern rtx        gen_insvdi                              (rtx, rtx, rtx, rtx);
extern rtx        gen_movdi                               (rtx, rtx);
extern rtx        gen_movsi                               (rtx, rtx);
extern rtx        gen_movhi                               (rtx, rtx);
extern rtx        gen_movqi                               (rtx, rtx);
extern rtx        gen_movsf                               (rtx, rtx);
extern rtx        gen_movdf                               (rtx, rtx);
extern rtx        gen_move_doubleword_fprdf               (rtx, rtx);
extern rtx        gen_move_doubleword_fprdi               (rtx, rtx);
extern rtx        gen_move_doubleword_fprtf               (rtx, rtx);
extern rtx        gen_movsicc                             (rtx, rtx, rtx, rtx);
extern rtx        gen_movdicc                             (rtx, rtx, rtx, rtx);
extern rtx        gen_movsfcc                             (rtx, rtx, rtx, rtx);
extern rtx        gen_movdfcc                             (rtx, rtx, rtx, rtx);
extern rtx        gen_clear_cache                         (rtx, rtx);
extern rtx        gen_cpymemsi                            (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchsi4                          (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchdi4                          (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchsf4                          (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchdf4                          (rtx, rtx, rtx, rtx);
extern rtx        gen_condjump                            (rtx, rtx);
extern rtx        gen_cstoresi4                           (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoredi4                           (rtx, rtx, rtx, rtx);
extern rtx        gen_jump                                (rtx);
extern rtx        gen_indirect_jump                       (rtx);
extern rtx        gen_tablejump                           (rtx, rtx);
extern rtx        gen_prologue                            (void);
extern rtx        gen_epilogue                            (void);
extern rtx        gen_sibcall_epilogue                    (void);
extern rtx        gen_return                              (void);
extern rtx        gen_simple_return                       (void);
extern rtx        gen_eh_return                           (rtx);
extern rtx        gen_sibcall                             (rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall_value                       (rtx, rtx, rtx, rtx);
extern rtx        gen_call                                (rtx, rtx, rtx, rtx);
extern rtx        gen_call_value                          (rtx, rtx, rtx, rtx);
extern rtx        gen_untyped_call                        (rtx, rtx, rtx);
extern rtx        gen_get_thread_pointersi                (rtx);
extern rtx        gen_get_thread_pointerdi                (rtx);
extern rtx        gen_mem_thread_fence                    (rtx);
extern rtx        gen_atomic_compare_and_swapsi           (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swapdi           (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_test_and_set                 (rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swapqi           (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swaphi           (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangeqi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangehi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_addqi                  (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_addhi                  (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subqi                  (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subhi                  (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_andqi                  (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_andhi                  (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xorqi                  (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xorhi                  (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_orqi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_orhi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_nandqi                 (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_nandhi                 (rtx, rtx, rtx, rtx);

#endif /* GCC_INSN_FLAGS_H */
